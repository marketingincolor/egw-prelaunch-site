<div class="mkd-social-share-holder mkd-list">
	<ul>
		<?php foreach ($networks as $net) {
			print $net;
		} ?>
	</ul>
</div>