<?php
require_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/google-map/google-map.php';

