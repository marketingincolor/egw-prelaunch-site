<?php
/**
 * Vertical Separator shortcode template
 */
?>

<span class='mkd-vertical-separator' <?php discussion_inline_style($separator_style);?>></span>