<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/image-with-hover-info/image-with-hover-info.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/image-with-hover-info/image-with-hover-info-item.php';
