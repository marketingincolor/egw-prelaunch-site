<span class="mkd-post-info-icon-holder">
    <span class="mkd-post-info-icon <?php echo esc_attr($params['post_type']) ?>"></span>
</span>