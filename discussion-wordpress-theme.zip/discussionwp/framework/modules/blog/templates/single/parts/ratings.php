<div class="mkd-ratings-holder">
    <div class="mkd-ratings-text-holder">
        <h6 class="mkd-ratings-text-title"><?php esc_html_e('Rate This Article', 'discussionwp' ); ?></h6>
        <div class="mkd-ratings-stars-holder">
            <div class="mkd-ratings-stars-inner">
                <span id="mkd-rating-1" ></span>
                <span id="mkd-rating-2" ></span>
                <span id="mkd-rating-3" ></span>
                <span id="mkd-rating-4" ></span>
                <span id="mkd-rating-5" ></span>
            </div>
        </div>
    </div>
    <div class="mkd-ratings-message-holder">
        <div class="mkd-rating-value"></div>
        <div class="mkd-rating-message"></div>
    </div>
</div>