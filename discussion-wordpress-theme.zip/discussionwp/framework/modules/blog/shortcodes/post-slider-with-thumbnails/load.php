<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/blog/shortcodes/post-slider-with-thumbnails/post-slider-with-thumbnails.php';