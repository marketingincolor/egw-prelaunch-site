<div class="mkd-bnl-navigation-holder">
    <div class="mkd-bnl-navigation">
        <a class="mkd-bnl-nav-icon mkd-bnl-nav-prev"><span class="ion-ios-arrow-left"></span></a>
        <a class="mkd-bnl-nav-icon mkd-bnl-nav-next"><span class="ion-ios-arrow-right"></span></a>
    </div>
</div>