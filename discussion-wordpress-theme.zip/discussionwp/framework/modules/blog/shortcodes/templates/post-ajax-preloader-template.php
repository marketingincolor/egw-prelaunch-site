<div class="mkd-post-ajax-preloader" style="display: none;">
	<div class="mkd-post-ajax-preloader-inner">
	    <div class="mkd-pulse"></div>
	    <div class="mkd-pulse"></div>
	    <div class="mkd-pulse"></div>
	</div>
</div>