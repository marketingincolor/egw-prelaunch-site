<?php

if (class_exists('SC_Class')) {
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/accesspresssocial/accesspresssocial-functions.php';
}