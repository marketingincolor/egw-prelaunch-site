<?php

require_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/recent-comments/recent-comments.php';
