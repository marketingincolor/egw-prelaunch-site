<?php

require_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/post-tabs/post-tabs.php';
