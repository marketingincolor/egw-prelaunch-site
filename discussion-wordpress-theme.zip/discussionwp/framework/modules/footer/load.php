<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/footer/options-map/map.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/footer/custom-styles/footer.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/footer/template-functions.php';
