<?php
discussion_get_footer();
?>