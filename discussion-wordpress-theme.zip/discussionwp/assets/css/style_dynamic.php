<?php

do_action('discussion_style_dynamic');